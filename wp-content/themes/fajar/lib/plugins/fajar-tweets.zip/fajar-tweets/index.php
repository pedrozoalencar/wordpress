<?php
/*
Plugin Name: Fajar WP Tweets
Plugin URI: http://gomalthemes.com/
Description: Fajar WP Tweets recent tweets plugin for only Fajar wp theme.
Version: 1.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
function fajar_addScripts(){
    // Register JavaScript.
    wp_register_script('fajar-tweets', plugins_url('tweets.js', __FILE__), array('jquery'), '', true);
    // Enqueue JavaScript.
    wp_enqueue_script('fajar-tweets');
}
add_action('wp_enqueue_scripts','fajar_addScripts');