<?php
/*
Plugin Name: Fajar Social Counts
Plugin URI: http://gomalthemes.com/
Description: Fajar Social counts plugin for only Fajar WP theme.
Version: 1.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
// Get Facebook Counts
function get_facebook_shares($url) {
    $whitelist = array(
        '127.0.0.1',
        '::1'
    );
    if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
        $completeUrl = 'http://graph.facebook.com/?id='.$url;
		$agent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)';
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_URL,$completeUrl);
		curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		$result = curl_exec($ch);
		curl_close($ch);
		$count = json_decode($result);
        if(isset($count->shares)){
            return $count->shares;
        } else {
            return '';
        }
    } else{
        return '';
    }
}
// Get Twitter Counts
function get_twitter_shares($url) {
    $whitelist = array(
        '127.0.0.1',
        '::1'
    );
    if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
        $completeUrl = 'http://urls.api.twitter.com/1/urls/count.json?url='.$url;
		$agent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)';
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_URL,$completeUrl);
		curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		$result = curl_exec($ch);
		curl_close($ch);
		$count = json_decode( $result );
		if(isset($count->count)){
            return $count->count;
        } else {
            return '';
        }
    } else {
        return '';
    }
}
// Get Pinterest Counts
function get_pinterest_shares($url) {
    $api = file_get_contents( 'http://api.pinterest.com/v1/urls/count.json?callback%20&url=' . $url );
    $body = preg_replace( '/^receiveCount\((.*)\)$/', '\\1', $api );
    $count = json_decode( $body );
    return $count->count;
}
// Get Linkedin Counts
function get_linkedin_shares($url) {
    $api = file_get_contents( 'https://www.linkedin.com/countserv/count/share?url=' . $url . '&format=json' );
    $count = json_decode( $api );
    return $count->count;
}
// Get Stumbleupon Counts
function get_stumbleupon_shares($url) {
    $api = file_get_contents( 'https://www.stumbleupon.com/services/1.01/badge.getinfo?url=' . $url );
    $count = json_decode( $api );
    return $count->result->views;
}
// Get Google Plus Counts
function get_google_plus_shares($url) {
    $curl = curl_init();
    curl_setopt( $curl, CURLOPT_URL, "https://clients6.google.com/rpc" );
    curl_setopt( $curl, CURLOPT_POST, 1 );
    curl_setopt( $curl, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"' . $url . '","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]' );
    curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $curl, CURLOPT_HTTPHEADER, array( 'Content-type: application/json' ) );
    $curl_results = curl_exec( $curl );
    curl_close( $curl );
    $json = json_decode( $curl_results, true );
    return intval( $json[0]['result']['metadata']['globalCounts']['count'] );
}