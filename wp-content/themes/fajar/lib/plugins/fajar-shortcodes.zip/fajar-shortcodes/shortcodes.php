<?php
/*
Plugin Name: Fajar Shortcodes
Plugin URI: http://gomalthemes.com/
Description: Fajar shortcodes provides a free set of different shortcodes for your wordpress theme!
Version: 2.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
?>
<?php
// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array(
        "container",
        "tri_services",
        "counters_with_icons",
        "team_members_two",
    ));
// opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}
// Container Shortcode
function container_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['class'])){
        $class = $atts['class'];
    } else {
        $class = '';
    }
    $out = '';
    $out .= '<div class="container '.$class.'">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('container', 'container_shortcode');
// Tri Services Shortcode
function tri_services_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['sm_heading'])){
        $sm_heading = $atts['sm_heading'];
    } else {
        $sm_heading = '';
    }
    if(!empty($atts['lg_heading'])){
        $lg_heading = $atts['lg_heading'];
    } else {
        $lg_heading = '';
    }
    if(!empty($atts['txt_desc'])){
        $txt_desc = $atts['txt_desc'];
    } else {
        $txt_desc = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }

    $out = '';
    $out .= '<div class="tri-sec text-center animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= '<h3 class="double-text"><small class="color-default">'.$sm_heading.'</small><br><b>'.$lg_heading.'</b></h3>';
    $out .= '<p>'.$txt_desc.'</p>';
    $out .= '</div>';
    return $out;
}
add_shortcode('tri_services', 'tri_services_shortcode');
// Counters With Icons Shortcode
function counters_with_icons_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    // Dependencies
    if(!empty($atts['counter_type'])){
        $counter_type = $atts['counter_type'];
    } else {
        $counter_type = '';
    }
    if(!empty($atts['icon_position'])){
        $icon_position = $atts['icon_position'];
    } else {
        $icon_position = 'text-left bottom';
    }
    if(!empty($atts['bg_color'])){
        $bg_color = 'style="background: '.$atts['bg_color'].';"';
    } else {
        $bg_color = '';
    }

    $out = '';
    if($counter_type == 'icon-behind'){
        $out .= '<div '.$bg_color.' class="text-center counter-iconic animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<div class="counter">';
        $out .= '<i class="'.$icon.' '.$icon_position.'"></i>';
        $out .= '<span class="quantity-counter quantity-counter1 highlight detect">'.$number.'</span>';
        $out .= '<h6 class="counter-details">'.rawurldecode(base64_decode(strip_tags($heading))).'</h6>';
        $out .= '</div>';
        $out .= '</div>';
    } elseif($counter_type == 'no-icon'){
        $out .= '<div class="counter text-center boxed animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<span class="quantity-counter quantity-counter1 highlight detect">'.$number.'</span>';
        $out .= '<h6 class="counter-details">'.rawurldecode(base64_decode(strip_tags($heading))).'</h6>';
        $out .= '</div>';
    } else{
        $out .= '<div class="numbering-sec" id="counters">';
        $out .= '<div class="text-center counter animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<i class="'.$icon.' simple-icon"></i>';
        $out .= '<span class="quantity-counter highlight detect">'.$number.'</span>';
        $out .= '<h6 class="counter-details">'.rawurldecode(base64_decode(strip_tags($heading))).'</h6>';
        $out .= '</div>';
        $out .= '</div>';
    }

    return $out;
}
add_shortcode('counters_with_icons', 'counters_with_icons_shortcode');
// Team Member Two Shortcode
function team_members_two_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['name'])){
        $name = $atts['name'];
    } else {
        $name = '';
    }
    if(!empty($atts['designation'])){
        $designation = $atts['designation'];
    } else {
        $designation = '';
    }
    if(!empty($atts['txt'])){
        $txt = $atts['txt'];
    } else {
        $txt = '';
    }
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = $atts['linkedin'];
    } else {
        $linkedin = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if(!empty($atts['txt_align'])){
        $txt_align= $atts['txt_align'];
    } else {
        $txt_align = 'text-center';
    }

    $out = '';
    if($style == 'inner'){
        $out .= '<div class="team-member '.$txt_align.' animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<div class="team-member-thumb">';
        $out .= $image;
        $out .= '<div class="overlay-fajar"></div>';
        $out .= '<ul class="social list-unstyled box small '.$txt_align.'">';
        if(!empty($facebook)){
            $out .= '<li><a href="'.$facebook.'" class="facebook"><i class="icon-facebook2"></i></a></li>';
        } if(!empty($twitter)){
            $out .= '<li><a href="'.$twitter.'" class="twitter"><i class="icon-twitter-1"></i></a></li>';
        } if(!empty($instagram)){
            $out .= '<li><a href="'.$instagram.'" class="instagram"><i class="icon-instagram4"></i></a></li>';
        } if(!empty($linkedin)){
            $out .= '<li><a href="'.$linkedin.'" class="linkedin"><i class="icon-linkedin4"></i></a></li>';
        } if(!empty($pinterest)){
            $out .= '<li><a href="'.$pinterest.'" class="pinterest"><i class="icon-pinterest4"></i></a></li>';
        }
        $out .= '</ul>';
        $out .= '</div>';
        $out .= '<div class="team-member-content">';
        $out .= '<h3>'.$name.'<span>'.$designation.'</span></h3>';
        $out .= '<p>'.$txt.'</p>';
        $out .= '</div>';
        $out .= '</div>';
    } else {
        $out .= '<div class="team-member '.$txt_align.' two animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<div class="team-member-thumb">';
        $out .= $image;
        $out .= '</div>';
        $out .= '<div class="team-member-content">';
        $out .= '<h3>'.$name.'<span>'.$designation.'</span></h3>';
        $out .= '<p>'.$txt.'</p>';
        $out .= '<ul class="social-text '.$txt_align.'">';
        if(!empty($facebook)){
            $out .= '<li><a href="#.">Facebok</a></li>';
        } if(!empty($twitter)){
            $out .= '<li> / </li><li><a href="#.">Twitter</a></li>';
        } if(!empty($linkedin)){
            $out .= '<li> / </li><li><a href="#.">Linkedin</a></li>';
        } if(!empty($pinterest)){
            $out .= '<li> / </li><li><a href="#.">Pinterest</a></li>';
        } if(!empty($instagram)){
            $out .= '<li> / </li><li><a href="#.">Instagram</a> </li>';
        }
        $out .= '</ul>';
        $out .= '</div>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('team_members_two', 'team_members_two_shortcode');
// Plain Title Shortcode
function plain_title_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title_bold_txt'])){
        $title_bold_txt = $atts['title_bold_txt'];
    } else {
        $title_bold_txt = '';
    }
    if(!empty($atts['title_normal_txt'])){
        $title_normal_txt = $atts['title_normal_txt'];
    } else {
        $title_normal_txt = '';
    }

    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = 'h2';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = 'drk';
    }
    if(!empty($atts['txt_align'])){
        $txt_align = $atts['txt_align'];
    } else {
        $txt_align = 'text-left';
    }
    if(!empty($atts['show_underline'])){
        $show_underline = $atts['show_underline'];
    } else {
        $show_underline = '';
    }
    if(!empty($atts['override_default_size'])){
        $override_default_size = 'style="font-size: '.$atts['override_default_size'].'px;"';
    } else {
        $override_default_size = '';
    }
    if(!empty($atts['description'])){
        $description = '<p>'.$atts['description'].'</p>';
    } else {
        $description = '';
    }
    if(!empty($atts['double_line'])){
        if($style == 'double'){
            $double_line = '<small>'.$atts['double_line'].'</small>';
            $double_class = 'double';
        } else {
            $double_line = '';
            $double_class = '';
        }

    } else {
        $double_line = '';
        $double_class = '';
    }
    $out = '';
    if(!empty($double_class)){
        $out .= '<div class="double-heading drk">';
    }
    $out .= '<'.$heading.' class="'.$style.' '.$txt_align.'" '.$override_default_size.'>';
    $out .= $double_line;
    $out .= '<strong>'.$title_bold_txt.'</strong> '.$title_normal_txt;
    if($show_underline == 'show'){
        if($txt_align == 'text-left'){
            $ta = 'style="margin-left: 0px;"';
        } else {
            $ta = '';
        }
        $out .= '<span class="line" '.$ta.'></span>';
    }
    $out .= '</'.$heading.'>';
    $out .= $description;
    if(!empty($double_class)){
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('plain_title', 'plain_title_shortcode');
// Skill bars Shortcode
function skill_bars_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = '';
    }
    if(!empty($atts['value'])){
        $value = $atts['value'];
    } else {
        $value = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if($style == 'square'){
        $class = 'square small';
    } else {
        $class = 'white';
    }
    $out = '';
    $out .= '<div class="skills-widget '.$class.'">';
    $out .= '<div class="progress" data-width="'.$value.'">';
    $out .= '<div class="progress-bar" role="progressbar" aria-valuenow="'.$value.'" aria-valuemin="0" aria-valuemax="100">';
    $out .= $title;
    $out .= '<div class="percentage">'.$value.'%</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('skill_bars', 'skill_bars_shortcode');
// Testimonials Shortcode
function testimonials_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['grp_slug'])){
        $grp_slug = $atts['grp_slug'];
        $args = array(
            'post_type' => 'fajar-testimonials',
            'posts_per_page' => $number,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'fajar_testimonials_genre',
                    'field'    => 'slug',
                    'terms'    => $grp_slug,
                ),
            ),
        );
    } else {
        $args = array(
            'post_type' => 'fajar-testimonials',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    // Style
    if(!empty($atts['style'])){
        $style = $atts['style'];
        if($style == 'light'){
            $class1 = 'testimonials2 text-center';
            $class2 = 'owl-carousel text-slider animations-on tada';
            $class3 = '';
        } elseif($style == 'img'){
            $class1 = 'testimonials animations-on fadeInLeft';
            $class2 = 'owl-carousel testimonial-carousel';
            $class3 = 'class="testimonial"';
        } else {
            $class1 = '';
            $class2 = 'owl-carousel text-center text-slider people-excited';
            $class3 = '';
        }
    } else {
        $class1 = '';
        $class2 = 'owl-carousel text-center text-slider people-excited';
        $class3 = '';
        $style = '';
    }
    if(!empty($atts['test_heading'])){
        $test_heading = '<h2>'.$atts['test_heading'].'</h2>';
    } else {
        $test_heading = '';
    }

    $out = '';
    if($style == 'white'){
        $out .= '<div class="what-client-say text-center animations-on">';
        $out .= $test_heading;
        $out .= '<i class="icon-quote-right"></i><i class="icon-quote-left"></i>';
        $out .= '<div class="owl-carousel text-slider">';
        $testimonials_query = new WP_Query($args);
        while($testimonials_query->have_posts()): $testimonials_query->the_post();
            $test_atuthor = get_field('test_atuthor');
            $test_designation = get_field('test_designation');
            $test_company_name = get_field('test_company_name');
            $test_author_image = get_field('test_author_image');
            $out .= '<div class="item">';
            $out .= '<p>'.get_the_content().'</p>';
            $out .= '<div class="about-client">';
            $out .= '<span>'.$test_atuthor.'</span>';
            $out .= '<p>'.$test_designation.' - '.$test_company_name.'</p>';
            $out .= '</div>';
            $out .= '</div>';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        $out .= '</div>';
    } elseif($style == 'circle-img'){
        $out .= '<div class="owl-carousel text-center text-slider people-excited">';
        $testimonials_query = new WP_Query($args);
        while($testimonials_query->have_posts()): $testimonials_query->the_post();
            $test_atuthor = get_field('test_atuthor');
            $test_designation = get_field('test_designation');
            $test_company_name = get_field('test_company_name');
            $test_author_image = get_field('test_author_image');
            $out .= '<div class="item">';
            $out .= '<p>We believe in coming up with original ideas Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce elementum, nulla vel pellentesque consequat, ante nulla </p>';
            $out .= '<div class="about-client">';
            if(!empty($test_author_image)){
                $out .= '<img class="thumbnail" src="'.$test_author_image.'" alt="">';
            }
            $out .= '<span>'.$test_atuthor.'</span>';
            $out .= '<p>'.$test_designation.' - '.$test_company_name.'</p>';
            $out .= '</div>';
            $out .= '</div>';
        endwhile;
    $out .= '</div>';
    } else {
        $out .= '<div class="'.$class1.'">';
        $out .= '<div class="'.$class2.'">';
        $testimonials_query = new WP_Query($args);
        while($testimonials_query->have_posts()): $testimonials_query->the_post();
            $test_atuthor = get_field('test_atuthor');
            $test_designation = get_field('test_designation');
            $test_company_name = get_field('test_company_name');
            $test_author_image = get_field('test_author_image');
            if(!empty($test_author_image)){
                $test_img = '<img src="'.$test_author_image.'" alt="" />';
            } else {
                $test_img = '';
            }
            $out .= '<div class="item">';
            $out .= '<div '.$class3.'><p>'.get_the_content().'</p></div>';
            if($style == 'img'){
                $out .= '<div class="client-detail color-white">';
                $out .= $test_img;
                $out .= '<span><strong>'.$test_atuthor.'</strong>'.$test_designation.' - '.$test_company_name.'</span>';
                $out .= '</div>';
            } else {
                $out .= '<div class="about-client">';
                $out .= '<span>'.$test_atuthor.'</span>';
                $out .= '<p>'.$test_designation.' - '.$test_company_name.'</p>';
                $out .= '</div>';
            }
            $out .= '</div>';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('testimonials', 'testimonials_shortcode');
// Rotating Title Shortcode
function rotating_title_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['text_before_rotate'])){
        $text_before_rotate = rawurldecode(base64_decode(strip_tags($atts['text_before_rotate'])));
    } else {
        $text_before_rotate = '';
    }
    if(!empty($atts['rotating_text'])){
        $rotating_text = '<span class="rotate">'. $atts['rotating_text']. '</span>';
    } else {
        $rotating_text = '';
    }
    if(!empty($atts['text_after_rotate'])){
        $text_after_rotate = rawurldecode(base64_decode(strip_tags($atts['text_after_rotate'])));
    } else {
        $text_after_rotate = '';
    }
    if(!empty($atts['text_desc'])){
        $text_desc = '<p>'.rawurldecode(base64_decode(strip_tags($atts['text_desc']))).'</p>';
    } else {
        $text_desc = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    // Title Style
    if(!empty($atts['style'])){
        $style = $atts['style'];
        if($style == 'light'){
            $class = 'white light text-rotator';
            $light = 'li8';
            $text_after_rotate = '<strong>'.$text_after_rotate.'</strong>';
        } else {
            $class = 'text-rotator';
            $light = '';
        }
    } else {
        $class = 'text-rotator';
        $light = '';
    }
    $out = '';
    $out .= '<div class="'.$light.' heading text-center animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= '<h2 class="'.$class.'">'.$text_before_rotate.' '.$rotating_text.' '.$text_after_rotate.'</h2>';
    $out .= $text_desc;
    $out .= '</div>';
    return $out;
}
add_shortcode('rotating_title', 'rotating_title_shortcode');
// Rotating Logos Shortcode
function rotating_logos_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="logos owl-carousel logos-carousel-5-items"><ul class="rslides logo1-rotater">';
    $out .= do_shortcode($content);
    $out .= '</ul></div>';
    return $out;
}
add_shortcode('rotating_logos', 'rotating_logos_shortcode');
add_shortcode('rotating_logo', 'rotating_logo_shortcode');
function rotating_logo_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    $out = '';
    $out .= '<li>';
    $out .= $image;
    $out .= '</li>';
    return $out;
}
// Tri Services 2 Shortcode
function tri_services2_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['icon'])){
        if(!empty($atts['style']) && $atts['style'] == 'circle'){
            $class = 'text-center';
            $icon = '<div class="round-icon-fill img-circle smooth"><i class="'.$atts['icon'].' img-circle smooth"></i></div>';
        } elseif(!empty($atts['style']) && $atts['style'] == 'circle-empty') {
            $class = 'text-center';
            $icon = '<div class="round-icon img-circle smooth"><i class="'.$atts['icon'].' img-circle smooth"></i></div>';
        } elseif(!empty($atts['style']) && $atts['style'] == 'pointer') {
            $class = 'text-center';
            $icon = '<div class="pointer"><i class="'.$atts['icon'].' smooth"></i></div>';
        } elseif(!empty($atts['style']) && $atts['style'] == 'icon-center') {
            $class = 'text-center';
            $icon = '<i class="'.$atts['icon'].' simple-icon smooth"></i>';
        } else {
            $class = 'text-left single';
            $icon = '<i class="'.$atts['icon'].' simple-icon smooth"></i>';
        }
    } else {
        $class = 'text-center';
        $icon = '';
    }
    if(!empty($atts['lg_heading'])){
        $lg_heading = $atts['lg_heading'];
        if(!empty($atts['style']) && $atts['style'] == 'left'){
            $lg_heading = $atts['lg_heading'];
        }
    } else {
        $lg_heading = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['icon_bg_color'])){
        $icon_bg_color = $atts['icon_bg_color'];
        $icon_bg_color = 'style="background: '.$icon_bg_color.';"';
    } else {
        $icon_bg_color = '';
    }

    $out = '';
    if(!empty($atts['style']) && $atts['style'] == 'beside'){
        $out .= '<div class="faded-tri-sec">';
        $out .= '<div class="lii animations-on '.$animations.'" data-delay="'.$delay.'">';
        if(!empty($atts['icon'])){
            $out .= '<i class="'.$atts['icon'].'" '.$icon_bg_color.'></i>';
        }
        $out .= '<div class="faded-tri-sec-content">';
        $out .= '<h3>'.$atts['lg_heading'].'</h3>';
        $out .= do_shortcode($content);
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
    } else {
        $out .= '<div class="tri-sec '.$class.' animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= $icon ;
        $out .= '<h3>'.$lg_heading.'</h3>';
        $out .= do_shortcode($content);
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('tri_services2', 'tri_services2_shortcode');
// Fancy Image Shortcode
function fancy_img_slides_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $id = '';
    if(!empty($atts['slider_type'])){
        $slider_type = $atts['slider_type'];
        if($slider_type == 'arrows-fancy'){
            $class1 = 'studio-slider animations-on fadeInLeft';
            $class2 = 'owl-carousel arrows-fancy img-slider';
        } elseif($slider_type == 'arrows-simple-dark') {
            $class1 = '';
            $class2 = 'owl-carousel arrows-simple-dark img-slider img-rounded2';
        }  elseif($slider_type == 'bullets-inside') {
            $class1 = '';
            $class2 = 'owl-carousel bullets img-slider';
        } else {
            $class1 = 'company-environment-slider text-center';
            $class2 = 'rslides';
            $id = 'id="company-environment-slider"';
        }
    } else {
        $slider_type = '';
        $class1 = 'studio-slider animations-on fadeInLeft';
        $class2 = 'owl-carousel arrows-fancy img-slider';
    }
    $out = '';
    $out .= '<div class="'.$class1.'"><div class="'.$class2.'" '.$id.'>';
    $out .= do_shortcode($content);
    $out .= '</div></div>';
    return $out;
}
add_shortcode('fancy_img_slides', 'fancy_img_slides_shortcode');
add_shortcode('fancy_img_slide', 'fancy_img_slide_shortcode');
function fancy_img_slide_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    $out = '';
    $out .= $image;
    return $out;
}
// Call To Action
function call_to_action_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['small_txt'])){
        $small_txt = $atts['small_txt'];
    } else {
        $small_txt = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    if($style == 'dark'){
        $out .= '<div class="banner-bottom animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<div class="container">';
        $out .= '<div class="row">';
        $out .= '<div class="col-md-8">';
        $out .= '<h3 class="light">'.rawurldecode(base64_decode(strip_tags($heading))).'</h3>';
        $out .= '<p>'.$small_txt.'</p>';
        $out .= '</div>';
        $out .= '<div class="col-md-4">';
        $out .= '<a href="'.$btn_link.'" class="btn btn-default pull-right">'.$btn_txt.'</a>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
    } else {
        $out .= '<div class="reading-box animations-on '.$animations.'" data-delay="'.$delay.'">';
        $out .= '<div class="row">';
        $out .= '<div class="col-md-9">';
        $out .= '<h2 class="light">'.rawurldecode(base64_decode(strip_tags($heading))).'</h2>';
        $out .= '<p>'.$small_txt.'</p>';
        $out .= '</div>';
        $out .= '<div class="col-md-3">';
        $out .= '<a href="'.$btn_link.'" class="btn btn-default">'.$btn_txt.'</a>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('call_to_action', 'call_to_action_shortcode');
// Contact Info Shortcode
function contact_info_boxes_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="contact-info-widget-boxed clearfix text-center"><ul>';
    $out .= do_shortcode($content);
    $out .= '</ul></div>';
    return $out;
}
add_shortcode('contact_info_boxes', 'contact_info_boxes_shortcode');
add_shortcode('contact_info_box', 'contact_info_box_shortcode');
function contact_info_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['info'])){
        $info = $atts['info'];
    } else {
        $info = '';
    }
    if(!empty($atts['icon'])){
        $icon = '<i class="'.$atts['icon'].'"></i>';
    } else {
        $icon = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<li class="animations-on '.$animations.'" data-delay="'.$delay.'"><p>';
    $out .= $icon;
    $out .= rawurldecode(base64_decode(strip_tags($info)));
    $out .= '</p></li>';
    return $out;
}
// Contact Widget Shortcode
function contact_widget_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = '';
    }
    if(!empty($atts['phone'])){
        $phone = $atts['phone'];
    } else {
        $phone = '';
    }
    if(!empty($atts['email'])){
        $email = $atts['email'];
    } else {
        $email = '';
    }
    if(!empty($atts['website'])){
        $website = $atts['website'];
    } else {
        $website = '';
    }
    if(!empty($atts['address'])){
        $address = $atts['address'];
    } else {
        $address = '';
    }
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['google'])){
        $google = $atts['google'];
    } else {
        $google = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = $atts['linkedin'];
    } else {
        $linkedin = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= '<div class="contact-info-widget">';
    $out .= '<h2 class="light">'.rawurldecode(base64_decode(strip_tags($title))).'</h2>';
    $out .= '<p>';
    if(!empty($phone)){
        $out .= '<strong>Phone:</strong> '.$phone.'<br>';
    } if(!empty($email)){
        $out .= '<strong>Email:</strong> <a href="mailto:'.$email.'">'.$email.'</a><br>';
    } if(!empty($website)){
        $out .= '<strong>Web:</strong> <a href="'.$website.'">'.$website.'</a><br>';
    }
    $out .= '<br>';
    if(!empty($address)){
        $out .= '<strong>Address:</strong>' . $address;
    }
    $out .= '</p>';
    $out .= '</div>';
    $out .= '<ul class="social list-unstyled boxed-dark-fill">';
    if(!empty($facebook)){
        $out .= '<li><a href="'.$facebook.'" class="facebook"><i class="icon-facebook2"></i></a></li>';
    } if(!empty($twitter)){
        $out .= '<li><a href="'.$twitter.'" class="twitter"><i class="icon-twitter-1"></i></a></li>';
    } if(!empty($google)){
        $out .= '<li><a href="'.$google.'" class="googleplus"><i class="icon-googleplus2"></i></a></li>';
    } if(!empty($linkedin)){
        $out .= '<li><a href="'.$linkedin.'" class="linkedin"><i class="icon-linkedin3"></i></a></li>';
    } if(!empty($pinterest)){
        $out .= '<li><a href="'.$pinterest.'" class="pinterest"><i class="icon-pinterest4"></i></a></li>';
    } if(!empty($instagram)){
        $out .= '<li><a href="'.$instagram.'" class="twitter"><i class="icon-instagram4"></i></a></li>';
    }
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
}
add_shortcode('contact_widget', 'contact_widget_shortcode');
// FAQ Shortcode
function f_faq_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['grp_slug'])){
        $grp_slug = $atts['grp_slug'];
        $args = array(
            'post_type' => 'fajar-faq',
            'posts_per_page' => $number,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'fajar_faq_genre',
                    'field'    => 'slug',
                    'terms'    => $grp_slug,
                ),
            ),
        );
    } else {
        $args = array(
            'post_type' => 'fajar-faq',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = 'paragraph';
    }
    $out = '';
    $faq_query = new WP_Query($args);
    $faq_count = 1;
    while($faq_query->have_posts()): $faq_query->the_post();
        $faq_animations_type = get_field('faq_animations_type');
        $faq_animation_delay = get_field('faq_animation_delay');
        $default_question_string = get_field('default_question_string');
        if($style == 'toggle'){
            if($faq_count == 1){
                $class = 'active';
            } else {
                $class = '';
            }
            $out .= '<div class="toggle '.$class.' animations-on '.$faq_animations_type.'" data-delay="'.$faq_animation_delay.'">';
            $out .= '<h3 class="toggle-heading">'.get_the_title().'</h3>';
            $out .= '<div class="toggle-content">';
            $out .= do_shortcode(get_the_content());
            $out .= '</div>';
            $out .= '</div>';
        } else {
            $out .= '<div class="faq animations-on '.$faq_animations_type.'" data-delay="'.$faq_animation_delay.'">';
            $out .= '<h3 class="question"><span>'.$default_question_string.'</span> '.get_the_title().'</h3>';
            $out .= '<div class="answer">';
            $out .= do_shortcode(get_the_content());
            $out .= '</div>';
            if($faq_count < $number){
                $out .= '<hr>';
            }
            $out .= '</div>';
        }
        $faq_count++;
    endwhile;
    wp_reset_query();
    return $out;
}
add_shortcode('f_faq', 'f_faq_shortcode');
// Creative Services Shortcode
function creative_services_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['hide_bg'])){
        $hide_bg = $atts['hide_bg'];
        if($hide_bg == 'hide'){
            $style_css = 'style="background: none !important;"';
        } else {
            $style_css = '';
        }
    } else {
        $hide_bg = '';
        $style_css = '';
    }
    if($number > 3){
        $bgr = 'bg-reapet-y';
    } else {
        $bgr = '';
    }
    $args = array(
        'post_type' => 'fajar-services',
        'posts_per_page' => $number,
        'order' => $order
    );
    $out = '';
    $services_query = new WP_Query($args);
    $services_count = 1;
    $out .= '<div class="creative-services-sec-bg '.$bgr.'" '.$style_css.'>';
    while($services_query->have_posts()): $services_query->the_post();
        $upload_number_icon = get_field('upload_number_icon');
        if(!empty($upload_number_icon)){
            $icon = 'style="background: url('.$upload_number_icon.') no-repeat scroll 0 0;"';
        } else {
            $icon = '';
        }
        $service_title_link = get_field('service_title_link');
        $icon_animations_type = get_field('icon_animations_type');
        $image_animations_type = get_field('image_animations_type');
        $feature_image_margin_top = get_field('feature_image_margin_top');
        if(!empty($feature_image_margin_top)){
            $fi_style = 'style="margin-top: '.$feature_image_margin_top.'px;"';
        } else {
            $fi_style = '';
        }

        // Last BG
        if($services_count < $number){
            $last_bg = '';
        } else {
            $last_bg = 'style="background: #fff;"';
        }
        if($services_count % 2 != 0){
            $out .= '<div class="creative-services-sec clearfix" '.$last_bg.'>';
            $out .= '<div class="number-icon pull-left animations-on '.$icon_animations_type.'" '.$icon.'>'.$services_count.'</div>';
            $out .= '<div class="creative-services-sec-content">';
            $out .= '<h2><a href="'.$service_title_link.'">'.get_the_title().'</a></h2>';
            $out .= do_shortcode(get_the_content());
            $out .= '</div>';
            $out .= '<div class="creative-services-sec-icon" '.$fi_style.'>';
            $out .= '<img class="board-icon animations-on '.$image_animations_type.'" data-delay="500" src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            $out .= '</div>';
            $out .= '</div>';
        } else{
            $out .= '<div class="creative-services-sec clearfix number-icon-right" '.$last_bg.'>';
            $out .= '<div class="number-icon pull-right animations-on '.$icon_animations_type.'" '.$icon.'>'.$services_count.'</div>';
            $out .= '<div class="creative-services-sec-content text-right">';
            $out .= '<h2><a href="'.$service_title_link.'">'.get_the_title().'</a></h2>';
            $out .= do_shortcode(get_the_content());
            $out .= '</div>';
            $out .= '<div class="creative-services-sec-icon umbrella" '.$fi_style.'>';
            $out .= '<img class="umbrella-icon animations-on '.$image_animations_type.'" data-delay="600" src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            $out .= '</div>';
            $out .= '</div>';
        }
    $services_count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('creative_services', 'creative_services_shortcode');
// Tooltip Icons Shortcode
function tooltip_icons_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="creative-process text-center">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('tooltip_icons', 'tooltip_icons_shortcode');
add_shortcode('tooltip_icon', 'tooltip_icon_shortcode');
function tooltip_icon_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tooltip_txt'])){
        $tooltip_txt = $atts['tooltip_txt'];
    } else {
        $tooltip_txt = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['data_placement'])){
        $data_placement = $atts['data_placement'];
    } else {
        $data_placement = 'top';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<i class="'.$style.' simple-round '.$icon.' animations-on '.$animations.'" data-delay="'.$delay.'" data-toggle="tooltip" data-placement="'.$data_placement.'" title="'.$tooltip_txt.'"></i>';
    return $out;
}
// Portfolio Recent Work Carousel Shortcode
function portfolio_recent_work_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['type'])){
        $type = $atts['type'];
    } else {
        $type = '';
    }
    if(!empty($atts['slug'])){
        $slug = $atts['slug'];
        $args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => -1,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'fajar_genre',
                    'field'    => 'slug',
                    'terms'    => $slug,
                ),
            ),
        );
    } else {
        $slug = '';
        $args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => -1,
            'order' => $order
        );
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    // Random Number
    $rand = rand(10,1000);
    $out = '';
    $portfolio_query = new WP_Query($args);
    if($type == 'info-top'){
        $out .= '<div id="our-work-demo"> <div class="owl-carousel recent-work-'.$rand.' animations-on '.$animations.'" data-delay="'.$delay.'">';
        while($portfolio_query->have_posts()): $portfolio_query->the_post();
            $out .= '<a href="'.get_the_permalink().'" class="item">';
            $out .= '<figure class="zoom-thumbnail">';
            $out .= '<img class="smooth" src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            $out .= '<figcaption class="smooth">';
            $out .= '<h3>';
            $terms = get_the_terms(get_the_ID(), 'fajar_genre');
            $term_counter = 0;
            $len = count($terms);
            $out .= '<small>';
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' / ';
                }
                $term_counter++;
            }
            $out .= '</small>';
            $out .= get_the_title();
            $out .= '</h3>';
            $out .= '</figcaption>';
            $out .= '</figure>';
            $out .= '</a>';
        endwhile;
        wp_reset_query();
        $out .= '</div></div>';
    } else {
        $out .= '<div class="owl-carousel recent-work-'.$rand.' arrows-simple-dark text-center small-arrows animations-on '.$animations.'" data-delay="'.$delay.'">';
        while($portfolio_query->have_posts()): $portfolio_query->the_post();
            $out .= '<div class="item">';
            $out .= '<div class="portfolio-item">';
            $out .= '<div class="portfolio-item-thumb">';
            $out .= '<a href="'.get_the_permalink().'"><img src="'.get_feature_image_url(get_the_ID()).'" alt=""></a>';
            $out .= '</div>';
            $out .= '<div class="portfolio-item-content">';
            $out .= '<h2>'.get_the_title().'</h2>';
            $terms = get_the_terms(get_the_ID(), 'fajar_genre');
            $term_counter = 0;
            $len = count($terms);
            $out .= '<p>';
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' / ';
                }
                $term_counter++;
            }
            $out .= '</p>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
    }

    $out .= '<script type="text/javascript">';
    $out .= 'jQuery(".recent-work-'.$rand.'").owlCarousel({
        items: '.$number.',
        itemsDesktop: [1199, '.$number.'],
        itemsDesktopSmall: [979, '.$number.'],
        itemsTablet: [768, '.$number.'],
        itemsMobile: [479, 1],
        navigation: true
    });';
    $out .= '</script>';
    return $out;
}
add_shortcode('portfolio_recent_work', 'portfolio_recent_work_shortcode');
// Awesome Feature List Shortcode
function awesome_feature_lists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="awesome-features list-unstyled">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('awesome_feature_lists', 'awesome_feature_lists_shortcode');
add_shortcode('awesome_feature_list', 'awesome_feature_list_shortcode');
function awesome_feature_list_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['text'])){
        $text = $atts['text'];
    } else {
        $text = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['position'])){
        $position = $atts['position'];
        if($position == 'text-left'){
            $pull = 'pull-left';
        } else {
            $pull = 'pull-right';
        }
    } else {
        $position = 'text-left';
        $pull = 'pull-left';
    }

    $out = '';
    $out .= '<li class="'.$position.'">';
    $out .= '<i class="'.$pull.' img-circle '.$icon.'"></i>';
    $out .= '<span>'.$heading.'</span>';
    $out .= $text;
    $out .= '</li>';
    return $out;
}
// Feature Un-ordered List Shortcode
function un_ordered_lists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="list-unstyled feature-list">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('un_ordered_lists', 'un_ordered_lists_shortcode');
add_shortcode('un_ordered_list', 'un_ordered_list_shortcode');
function un_ordered_list_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['text'])){
        $text = $atts['text'];
    } else {
        $text = '';
    }
    if(!empty($atts['icon'])){
        $icon = '<i class="'.$atts['icon'].'"></i>';
    } else {
        $icon = '';
    }

    $out = '';
    $out .= '<li>'.$icon.' '.$text.'</li>';
    return $out;
}
// History Slider Shortcode
function history_slides_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="history" id="history-slider">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('history_slides', 'history_slides_shortcode');
add_shortcode('history_slide', 'history_slide_shortcode');
function history_slide_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['images'])){
        $images = $atts['images'];
    } else {
        $images = '';
    }
    if(!empty($atts['img_animations'])){
        $img_animations = $atts['img_animations'];
    } else {
        $img_animations = '';
    }
    if(!empty($atts['img_delay'])){
        $img_delay = $atts['img_delay'];
    } else {
        $img_delay = '';
    }
    if(!empty($atts['year'])){
        $year = $atts['year'];
    } else {
        $year = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['content_animations'])){
        $content_animations = $atts['content_animations'];
    } else {
        $content_animations = '';
    }
    if(!empty($atts['content_delay'])){
        $content_delay = $atts['content_delay'];
    } else {
        $content_delay = '';
    }

    $out = '';
    $out .= '<li class="row">';
    $out .= '<div class="col-md-6 animations-on '.$img_animations.'" data-delay="'.$img_delay.'">';
    $out .= '<div class="image-slider bullets owl-carousel">';
    $ex_images = explode(',',$images);
    foreach($ex_images as $attach_id){
        $image_info = wp_get_attachment_image_src( $attach_id, 'full' );
        $out .= '<img src="'.$image_info[0].'" alt="">';
    }
    $out .= '</div>';
    $out .= '</div>';
    $out .= '<div class="col-md-6 animations-on '.$content_animations.'" data-delay="'.$content_delay.'">';
    $out .= '<p class="history-date color-default">'.$year.'</p>';
    $out .= '<h2 class="light">'.rawurldecode(base64_decode(strip_tags($heading))).'</h2>';
    $out .= do_shortcode(rawurldecode(base64_decode(strip_tags($description))));
    $out .= '</div>';
    $out .= '</li>';
    return $out;
}
// History Slider Pagination Shortcode
function history_slider_pagination_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['years'])){
        $years = $atts['years'];
    } else {
        $years = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<ul id="history-slider-pager" class="animations-on '.$animations.'" data-delay="'.$delay.'">';
    $ex_years = explode(',',$years);
    $year_count = 1;
    foreach($ex_years as $year){
        if($year_count % 2 != 0){
            $out .= '<li><a href="#.">'.$year.'<br><i class="icon-dot"></i></a></li>';
        } else {
            $out .= '<li><a href="#."><i class="icon-dot"></i><br>'.$year.'</a></li>';
        }
    $year_count++;
    }
    $out .= '</ul>';
    return $out;
}
add_shortcode('history_slider_pagination', 'history_slider_pagination_shortcode');
// Career Tabs Shortcode
function career_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tab_headings'])){
        $tab_headings = $atts['tab_headings'];
    } else {
        $tab_headings = '';
    }
    $out = '';
    $out .= '<div class="careers simple-tabs careers-tabs animations-on fadeInUp">';
    $out .= '<ul class="resp-tabs-list tabs clearfix text-center">';
    $ex_tab_headings = explode('+',$tab_headings);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        $out .= '<li><a href="#." id="tab'. $heading_count .'">' . $heading . '</a></li>';
        $heading_count++;
    }
    $out .= '</ul>';
    $out .= '<div class="resp-tabs-container">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('career_tabs', 'career_tabs_shortcode');
add_shortcode('career_tab', 'career_tab_shortcode');
function career_tab_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    $out = '';
    $out .= '<div>';
    $out .= '<h2 class="light">'.rawurldecode(base64_decode(strip_tags($heading))).'</h2>';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
// Scroll Button
function scroll_btn_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    $out = '';
    $out .= '<div>';
    $out .= '<a class="btn btn-bordered black scroll" href="'.$btn_link.'">'.$title.'</a>';
    return $out;
}
add_shortcode('scroll_btn', 'scroll_btn_shortcode');
// Thumbnail Slider Shortcode
function thumbnail_slides_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '<ul class="rslides fajar-digital-agency img-slider-with-thumbs">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('thumbnail_slides', 'thumbnail_slides_shortcode');
add_shortcode('thumbnail_slide', 'thumbnail_slide_shortcode');
function thumbnail_slide_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<li><img src="'.$image_info[0].'" alt=""></li>';
    } else {
        $image = '';
    }
    $out = '';
    $out .= $image;
    return $out;
}
// Thumbnail Slider Thumbs
function thumbnail_slider_thumbs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['images'])){
        $images = $atts['images'];
    } else {
        $images = '';
    }
    $out = '';
    $out .= '<ul class="clearfix img-slider-pager fajar-digital-agency img-slider-with-thumbs-pager">';
    $ex_images = explode(',',$images);
    foreach($ex_images as $img_id){
        $image_info = wp_get_attachment_image_src( $img_id, 'full' );
        $out .= '<li><a href="#"><img src="'.$image_info[0].'" alt=""></a></li>';
    }
    $out .= '</ul>';
    return $out;
}
add_shortcode('thumbnail_slider_thumbs', 'thumbnail_slider_thumbs_shortcode');
// Partner Tabs Shortcode
function partner_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tab_headings'])){
        $tab_headings = rawurldecode(base64_decode(strip_tags($atts['tab_headings'])));
    } else {
        $tab_headings = '';
    }
    $out = '';
    $out .= '<div class="company-partners animations-on fadeInUp company-partners-tabs" data-delay="400">';

    $out .= '<div class="resp-tabs-container">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '<ul class="resp-tabs-list partners-name clearfix text-center">';
    $ex_tab_headings = explode('+',$tab_headings);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        $out .= '<li><a href="#." id="partners-'. $heading_count .'">' . $heading . '</a></li>';
        $heading_count++;
    }
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
}
add_shortcode('partner_tabs', 'partner_tabs_shortcode');
add_shortcode('partner_tab', 'partner_tab_shortcode');
function partner_tab_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['description'])){
        $description = rawurldecode(base64_decode(strip_tags($atts['description'])));
    } else {
        $description = '';
    }
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    $out = '';
    $out .= '<div class="partners-content clearfix">';
    $out .= $image;
    $out .= '<p>'.$description.'</p>';
    $out .= '<ul class="social list-unstyled box">';
    if(!empty($facebook)){
        $out .= '<li><a href="'.$facebook.'" class="facebook"><i class="icon-facebook-1"></i></a></li>';
    } if(!empty($twitter)){
        $out .= '<li><a href="'.$twitter.'" class="twitter"><i class="icon-twitter-1"></i></a></li>';
    } if(!empty($instagram)){
        $out .= '<li><a href="'.$instagram.'" class="instagram"><i class="icon-instagram4"></i></a></li>';
    } if(!empty($pinterest)){
        $out .= '<li><a href="'.$pinterest.'" class="pinterest"><i class="icon-pinterest4"></i></a></li>';
    }
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
}
// Feature Box
function feature_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['icon_color'])){
        $icon_color = $atts['icon_color'];
    } else {
        $icon_color = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $rand = rand(10,1000);
    $out = '';
    $out .= '<div class="boxed-tri-sec animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= '<div class="class-'.$rand.' pointer-icon"><span class="shadow"></span><i class="'.$icon.'"></i></div>';
    $out .= '<h3>'.$heading.'</h3>';
    $out .= '<p>'.$description.'</p>';
    $out .= '</div>';
    if(!empty($atts['icon_color'])){
        $out .= '<style type="text/css">
        .class-'.$rand.'.pointer-icon {
            background: '.$icon_color.';
        } .class-'.$rand.'.pointer-icon:after {
            border-top-color: '.$icon_color.';
        }
        </style>';
    }
    return $out;
}
add_shortcode('feature_box', 'feature_box_shortcode');
// Blog Posts Shortcode
function blog_posts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $s_number = $number;
    if($style == 'carousel'){
        $number = -1;
    }
    if(!empty($atts['cat_slug'])){
        $cat_slug = $atts['cat_slug'];
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order,
            'category_name' => $cat_slug
        );
    } else {
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $blog_query = new WP_Query($args);
    if($style == 'accordion'){
        $out .= '<div class="blog-post-classic-sec">';
        while($blog_query->have_posts()): $blog_query->the_post();
            $animation = get_field('choose_post_animation');
            $out .= '<article class="blog-post-classic clearfix animations-on '.$animation.'">';
            $out .= '<p class="date">'.get_the_time('M d, Y').'</p>';
            $out .= '<a href="'.get_the_permalink().'">';
            $out .= get_the_title();
            $cats = get_the_category(get_the_ID());
            $out .= '<span>';
            $post_count = 0;
            $len = count($cats);
            foreach($cats as $cat){
                if ($post_count == $len - 1) {
                    $out .= $cat->cat_name;
                } else {
                    $out .= $cat->cat_name. ', ';
                }
                $post_count++;
            }
            $out .= '</span>';
            $out .= '<i class="icon-plus7"></i>';
            $out .= '</a>';
            $out .= '</article>';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
    } elseif($style == 'carousel'){
        $js = "
        <script type='text/javascript'>
            jQuery('.recent-news-carousel').owlCarousel({
            items: ".$s_number.",
            itemsDesktop: [1199, ".$s_number."],
            itemsDesktopSmall: [979, 2],
            itemsTablet: [768, 2],
            itemsMobile: [479, 1]
        });
        </script>
        ";
        $out .= '<div class="recent-news-carousel owl-carousel">';
        $blog_count = 1;
        while($blog_query->have_posts()): $blog_query->the_post();
            $animation = get_field('choose_post_animation');
        $out .= '<div class="recent-news zoom-thumbnail dark">';
        if(has_post_thumbnail()){
            $out .= '<img class="smooth" src="'.get_feature_image_url(get_the_ID()).'" alt="">';
        }
        $out .= '<div class="recent-news-caption">';
        $out .= '<h3>';
        $out .= '<small>'.get_the_time('M d, Y').'</small>';
        $out .= '<a href="'.get_the_permalink().'">'.get_the_title().'</a>';
        $out .= '</h3>';
        $out .= '<p>'.esc_attr__('By','fajar-wp').' '.get_the_author().'<a href="'.get_the_permalink().'">'.get_comments_number( '0', '1', '%' ).' '.esc_attr__('Comments','fajar-wp').'</a></p>';
        $out .= '</div>';
        $out .= '</div>';
        $blog_count++;
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        $out .= $js;
    } else {
        $blog_count = 1;
        while($blog_query->have_posts()): $blog_query->the_post();
            $animation = get_field('choose_post_animation');
            $out .= '<div class="col-md-4">';
            $out .= '<article class="latest-blog-post animations-on '.$animation.'" data-delay="100">';
            if(has_post_thumbnail()){
                $out .= '<a href="'.get_permalink().'"><img src="'.get_feature_image_url(get_the_ID()).'" alt=""></a>';
            }
            $out .= '<div class="latest-blog-post-content">';
            $out .= '<h3><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';
            $out .= '<p>'.fajar_excerpt2(100).'</p>';
            $out .= '<ul class="latest-blog-meta clearfix">';
            $out .= '<li>'.get_the_time('M d, Y').'</li>';
            $out .= '<li><a href="javascript:void(0);"><i class="icon-eye"></i>'.getPostViews(get_the_ID()).'</a></li>';
            $out .= '<li><a href="'.get_the_permalink().'"><i class="icon-chat-1"></i>'.get_comments_number( '0', '1', '%' ).'</a></li>';
            $out .= '</ul>';
            $out .= '</div>';
            $out .= '</article>';
            $out .= '</div>';
        if($blog_count % 3 == 0){
            $out .= '<div class="clear clearfix"></div>';
        }
        $blog_count++;
        endwhile;
        wp_reset_query();
    }
    return $out;
}
add_shortcode('blog_posts', 'blog_posts_shortcode');
// Plain Partners Shortcode
function plain_partners_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    $out = '';
    $out .= '<div class="company-partners2 owl-carousel company-partners-carousel">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '<script type="text/javascript">
    jQuery(".company-partners-carousel").owlCarousel({
        items: '.$number.',
        itemsDesktop: [1199, '.$number.'],
        itemsDesktopSmall: [979, '.$number.'],
        itemsTablet: [768, '.$number.'],
        itemsMobile: [479, 1]
    });
    </script>';
    return $out;
}
add_shortcode('plain_partners', 'plain_partners_shortcode');
add_shortcode('plain_partner', 'plain_partner_shortcode');
function plain_partner_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['name'])){
        $name = $atts['name'];
    } else {
        $name = '';
    }
    if(!empty($atts['designation'])){
        $designation = $atts['designation'];
    } else {
        $designation = '';
    }
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="company-partner animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= $image;
    $out .= '<div class="company-partner-description">';
    $out .= '<ul class="social-simple">';
    if(!empty($facebook)){
        $out .= '<li><a href="'.$facebook.'" class="facebook"><i class="icon-facebook-1"></i></a></li>';
    } if(!empty($twitter)){
        $out .= '<li><a href="'.$twitter.'" class="twitter"><i class="icon-twitter-1"></i></a></li>';
    } if(!empty($instagram)){
        $out .= '<li><a href="'.$instagram.'" class="instagram"><i class="icon-instagram4"></i></a></li>';
    } if(!empty($pinterest)){
        $out .= '<li><a href="'.$pinterest.'" class="pinterest"><i class="icon-pinterest4"></i></a></li>';
    }
    $out .= '</ul>';
    $out .= '<h3>'.$name.'<span>'.$designation.'</span></h3>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
// Portfolio Masonry
function portfolio_masonry_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['slug'])){
        $slug = $atts['slug'];
        $args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => $number,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'fajar_genre',
                    'field'    => 'slug',
                    'terms'    => $slug,
                ),
            ),
        );
    } else {
        $slug = '';
        $args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    if($style == 'grid'){
        $out .= '<ul class="portfolio clearfix animations-on '.$animations.'" data-delay="'.$delay.'">';
        $portfolio_query = new WP_Query($args);
        while($portfolio_query->have_posts()): $portfolio_query->the_post();
            $out .= '<li>';
            $out .= '<div class="portfolio-item">';
            if(has_post_thumbnail()){
                $out .= '<img src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            }
            $out .= '<a href="'.get_the_permalink().'" class="project-detail"><i class="icon-grid6"></i></a>';
            $out .= '<a href="'.get_feature_image_url(get_the_ID()).'" class="project-zoom fancybox" data-fancybox-group="portfolio"><i class="icon-eye"></i></a>';
            $out .= '<div class="portfolio-item-info">';
            $out .= '<h3>'.get_the_title().'<small>';
            $terms = get_the_terms(get_the_ID(), 'fajar_genre');
            $term_counter = 0;
            $len = count($terms);
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' / ';
                }
                $term_counter++;
            }
            $out .= '</small></h3>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</li>';
        endwhile;
        wp_reset_query();
        $out .= '</ul>';
    } elseif($style == 'grid-plain'){
        $out .= '<div class="our-work-sec">';
        $out .= '<ul class="awesome-products clearfix animations-on '.$animations.'" data-delay="'.$delay.'">';
        $portfolio_query = new WP_Query($args);
        while($portfolio_query->have_posts()): $portfolio_query->the_post();
            $out .= '<li>';
			$out .= '<a href="'.get_the_permalink().'">';
			$out .= '<figure class="zoom-thumbnail dark">';
            if(has_post_thumbnail()){
                $out .= '<img class="smooth" src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            }
			$out .= '<figcaption class="smooth align-middle">';
            $out .= '<h3>'.get_the_title().'<small>';
            $terms = get_the_terms(get_the_ID(), 'fajar_genre');
            $term_counter = 0;
            $len = count($terms);
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' / ';
                }
                $term_counter++;
            }
            $out .= '</small></h3>';
            $out .= '</figcaption>';
			$out .= '</figure>';
			$out .= '</a>';
			$out .= '</li>';
        endwhile;
        wp_reset_query();
        $out .= '</ul>';
        $out .= '</div>';
    } else {
        $out .= '<div class="portfolio-masonary clearfix animations-on '.$animations.'" data-delay="'.$delay.'">';
        $portfolio_query = new WP_Query($args);
        while($portfolio_query->have_posts()): $portfolio_query->the_post();
            $out .= '<div class="portfolio-masonary-column">';
            $out .= '<div class="portfolio-masonary-item">';
            if(has_post_thumbnail()){
                $out .= '<img src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            }
            $out .= '<a href="'.get_the_permalink().'" class="portfolio-masonary-content smooth">';
            $terms = get_the_terms(get_the_ID(), 'fajar_genre');
            $term_counter = 0;
            $len = count($terms);
            $out .= '<small>';
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' / ';
                }
                $term_counter++;
            }
            $out .= '</small>';
            $out .= get_the_title();
            $out .= '</a>';
            $out .= '</div>';
            $out .= '</div>';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
    }

    return $out;
}
add_shortcode('portfolio_masonry', 'portfolio_masonry_shortcode');
// Popup Video
function pop_up_video_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['video'])){
        $video = $atts['video'];
    } else {
        $video = '';
    }
    if(!empty($atts['text'])){
        $text = $atts['text'];
    } else {
        $text = 'Watch the video';
    }
    if(!empty($atts['text_color'])){
        $text_color = 'style="color: '.$atts['text_color'].';"';
    } else {
        $text_color = '';
    }
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '<img src="'.plugins_url( 'images/play-btn.png', __FILE__ ).'" alt="">';
    }

    $out = '';
    $out .= '<a href="'.$video.'" class="play-video-btn fancybox-media" '.$text_color.'>';
    $out .= $image;
    $out .= $text;
    $out .= '</a>';
    return $out;
}
add_shortcode('pop_up_video', 'pop_up_video_shortcode');
// Process Tabs Shortcode
function process_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tab_headings'])){
        $tab_headings = rawurldecode(base64_decode(strip_tags($atts['tab_headings'])));
    } else {
        $tab_headings = '';
    }
    $out = '';
    $out .= '<div class="our-process-tabs our-process-tab animations-on fadInUp">';
    $out .= '<ul class="resp-tabs-list tabs clearfix text-center">';
    $ex_tab_headings = explode('++',$tab_headings);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        $out .= '<li><a href="#." id="tab'. $heading_count .'">' . $heading . '</a></li>';
        $heading_count++;
    }
    $out .= '</ul>';
    $out .= '<div class="resp-tabs-container">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('process_tabs', 'process_tabs_shortcode');
add_shortcode('process_tab', 'process_tab_shortcode');
function process_tab_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = 'style="background: url('.$image_info[0].') no-repeat 0 0;"';

    } else {
        $image = '';
    }
    $out = '';
    $out .= '<div>';
    $out .= '<div class="process icon1" '.$image.'>';
    $out .= '<h2 class="light">'.rawurldecode(base64_decode(strip_tags($heading))).'</h2>';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
// Custom Latest Work Shortcode
function c_latest_works_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div id="latest-work-slider-wide">';
    $out .= '<div class="latest-work-slider arrows-fancy-dark-transparent">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('c_latest_works', 'c_latest_works_shortcode');
add_shortcode('c_latest_work', 'c_latest_work_shortcode');
function c_latest_work_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
        $image2 = $image_info[0];
    } else {
        $image = '';
        $image2 = '';
    }
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = '';
    }
    if(!empty($atts['description'])){
        $description = rawurldecode(base64_decode(strip_tags($atts['description'])));
    } else {
        $description = '';
    }
    if(!empty($atts['date'])){
        $date = $atts['date'];
    } else {
        $date = '';
    }
    if(!empty($atts['category'])){
        $category = $atts['category'];
    } else {
        $category = '';
    }
    if(!empty($atts['social_share'])){
        $social_share = $atts['social_share'];
    } else {
        $social_share = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    $out = '';
    $out .= '<div class="container">';
    $out .= '<div class="row animations-on fadeInUp">';
    $out .= '<div class="col-md-6">';
    $out .= $image;
    $out .= '</div>';
    $out .= '<div class="col-md-6">';
    $out .= '<h3><strong>'.$title.'</strong></h3>';
    $out .= '<p>'.$description.'</p>';
    $out .= '<div class="row">';
    $out .= '<div class="col-md-5">';
    if(!empty($date)){
        $out .= '<h4><strong>Date</strong></h4>';
        $out .= '<p>'.$date.'</p>';
    }
    $out .= '</div>';
    $out .= '<div class="col-md-7">';
    if(!empty($category)){
        $out .= '<h4><strong>Category</strong></h4>';
        $out .= '<p>'.$category.'</p>';
    }
    $out .= '</div>';
    $out .= '</div>';
    $out .= '<br>';
    if($social_share != 'yes'){
        $out .= '<ul class="social-with-number">';
        $out .= '<li>';
        $out .= '<a href="http://www.facebook.com/sharer.php?u='.$btn_link.'&amp;t='.$title.'" class="facebook">';
        $out .= '<i class="fa fa-facebook"></i>';
        if(function_exists("get_facebook_shares")){
            $gfs = get_facebook_shares($btn_link);
            if(!empty($gfs)){
                $out .= $gfs;
            } else {
                $out .= '0';
            }
        }
        $out .= '</a>';
        $out .= '</li>';
        $out .= '<li>';
        $out .= '<a href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.$btn_link.'&amp;title='.$title.'&amp;source='.get_home_url().'" class="twitter">';
        $out .= '<i class="fa fa-linkedin"></i>';
        if(function_exists('get_linkedin_shares')){
            $gls = get_linkedin_shares(get_permalink());
            if(!empty($gls)){
                $out .= $gls;
            } else {
                $out .= '0';
            }
        }
        $out .= '</a>';
        $out .= '</li>';
        $out .= '<li>';
        $out .= '<a href="https://plusone.google.com/_/+1/confirm?hl=en-US&amp;url='.$btn_link.'" class="google-plus">';
        $out .= '<i class="fa fa-google-plus"></i>';
        if(function_exists('get_google_plus_shares')){
            $out .= get_google_plus_shares(get_permalink());
        }
        $out .= '</a>';
        $out .= '</li>';
        $out .= '<li>';
        $out .= '<a href="//pinterest.com/pin/create/button/?url='.$btn_link.'&amp;media='.$image2.'&amp;description='.$title.'" class="mouth">';
        $out .= '<i class="fa fa-pinterest"></i>';
        if(function_exists('get_pinterest_shares')){
            $out .= get_pinterest_shares(get_permalink());
        }
        $out .= '</a>';
        $out .= '</li>';
        $out .= '</ul>';
    }
    $out .= '<br>';
    if(!empty($btn_txt)){
        $out .= '<a href="'.$btn_link.'" class="btn btn-dark btn-square btn-medium">'.$btn_txt.'</a>';
    }
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
// Four Image Process Shortcode
function four_image_process_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image1'])){
        $image_info = wp_get_attachment_image_src( $atts['image1'], 'full' );
        $image1 = $image_info[0];
    } else {
        $image1 = '';
    }
    if(!empty($atts['heading1'])){
        $heading1 = $atts['heading1'];
    } else {
        $heading1 = '';
    }
    if(!empty($atts['image2'])){
        $image_info = wp_get_attachment_image_src( $atts['image2'], 'full' );
        $image2 = $image_info[0];
    } else {
        $image2 = '';
    }
    if(!empty($atts['heading2'])){
        $heading2 = $atts['heading2'];
    } else {
        $heading2 = '';
    }
    if(!empty($atts['image3'])){
        $image_info = wp_get_attachment_image_src( $atts['image3'], 'full' );
        $image3 = $image_info[0];
    } else {
        $image3 = '';
    }
    if(!empty($atts['heading3'])){
        $heading3 = $atts['heading3'];
    } else {
        $heading3 = '';
    }
    if(!empty($atts['image4'])){
        $image_info = wp_get_attachment_image_src( $atts['image4'], 'full' );
        $image4 = $image_info[0];
    } else {
        $image4 = '';
    }
    if(!empty($atts['heading4'])){
        $heading4 = $atts['heading4'];
    } else {
        $heading4 = '';
    }
    $out = '';
    $out .= '<section class="creative-sec no-padding-top">';
    $out .= '<div class="container">';
    $out .= '<div class="creative-sec-thumb one animations-on bounceIn">';
    $out .= '<figure>';
    $out .= '<img src="'.$image1.'" width="154" class="img-circle img-thumbnail img-responsive" alt="" title="">';
    $out .= '<figcaption>'.$heading1.'</figcaption>';
    $out .= '</figure>';
    $out .= '</div>';
    $out .= '<div class="creative-sec-thumb two animations-on bounceIn" data-delay="100">';
    $out .= '<figure>';
    $out .= '<img src="'.$image2.'" width="266" class="img-circle img-thumbnail img-responsive" alt="" title="">';
    $out .= '<figcaption>'.$heading2.'</figcaption>';
    $out .= '</figure>';
    $out .= '</div>';
    $out .= '<div class="creative-sec-thumb three animations-on bounceIn" data-delay="300">';
    $out .= '<figure>';
    $out .= '<img src="'.$image3.'" width="162" class="img-circle img-thumbnail img-responsive" alt="" title="">';
    $out .= '<figcaption>'.$heading3.'</figcaption>';
    $out .= '</figure>';
    $out .= '</div>';
    $out .= '<div class="creative-sec-thumb four animations-on bounceIn" data-delay="600">';
    $out .= '<figure>';
    $out .= '<img src="'.$image4.'" width="305" class="img-circle img-thumbnail img-responsive" alt="" title="">';
    $out .= '<figcaption>'.$heading4.'</figcaption>';
    $out .= '</figure>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</section>';
    return $out;
}
add_shortcode('four_image_process', 'four_image_process_shortcode');
// Creative Process Number
function creative_process_number_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    $out = '';
    $out .= '<div class="tri-sec-number">';
	$out .= '<span class="number color-default">'.$number.'</span>';
	$out .= '<h3>'.$heading.'</h3>';
	$out .= '<p>'.$description.'</p>';
	$out .= '</div>';
    return $out;
}
add_shortcode('creative_process_number', 'creative_process_number_shortcode');
// Slider With Text Overlay Shortcode
function slides_overlay_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $id = '';
    if(!empty($atts['caption'])){
        $caption = $atts['caption'];
    } else {
        $caption = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    $out = '';
    $out .= '<div class="bg-image-slider">';
	$out .= '<div class="bg-image-slides">';
    $out .= do_shortcode($content);
	$out .= '</div>';
	$out .= '<div class="bg-image-slider-text">';
	$out .= '<p><small>'.$caption.'</small>'.$heading.'</p>';
	$out .= '</div>';
	$out .= '</div>';
    return $out;
}
add_shortcode('slides_overlay', 'slides_overlay_shortcode');
add_shortcode('slide_overlay', 'slide_overlay_shortcode');
function slide_overlay_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    $out = '';
    $out .= $image;
    return $out;
}
// Services Block Shortcode
function services_block_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['img_position'])){
        $img_position = $atts['img_position'];
    } else {
        $img_position = 'left';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['heading'])){
        $heading = rawurldecode(base64_decode(strip_tags($atts['heading'])));
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    if(!empty($atts['color'])){
        $color = 'style="background: '.$atts['color'].';"';
    } else {
        $color = '';
    }
    $out = '';
    if($img_position == 'left'){
        $out .= '<section class="folio no-padding clearfix" '.$color.'>';
        $out .= '<div class="folio-img">'.$image.'</div>';
        $out .= '<div class="folio-caption">';
        $out .= '<i class="'.$icon.'"></i>';
        $out .= '<h2>'.$heading.'</h2>';
        $out .= '<p>'.$description.'</p>';
        if(!empty($btn_txt)){
            $out .= '<a href="'.$btn_link.'" class="btn btn-dark">'.$btn_txt.'</a>';
        }
        $out .= '</div>';
        $out .= '</section>';
    } else {
        $out .= '<section class="folio no-padding clearfix" '.$color.'>';
        $out .= '<div class="folio-img right-img">'.$image.'</div>';
        $out .= '<div class="folio-caption">';
        $out .= '<i class="'.$icon.'"></i>';
        $out .= '<h2>'.$heading.'</h2>';
        $out .= '<p>'.$description.'</p>';
        if(!empty($btn_txt)){
            $out .= '<a href="'.$btn_link.'" class="btn btn-dark">'.$btn_txt.'</a>';
        }
        $out .= '</div>';
        $out .= '</section>';
    }
    return $out;
}
add_shortcode('services_block', 'services_block_shortcode');
// General Tabs Shortcode
function general_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tab_headings'])){
        $tab_headings = $atts['tab_headings'];
    } else {
        $tab_headings = '';
    }
    if(!empty($atts['tabs_position'])){
        $tabs_position = $atts['tabs_position'];
    } else {
        $tabs_position = '';
    }
    if($tabs_position == 'right'){
        $class1 = 'normal-tabs tabs-right-nav';
        $class2 = 'resp-tabs-list tabs clearfix text-center';
    } elseif($tabs_position == 'side'){
        $class1 = 'clearfix normal-tabs-vertical verticalTab';
        $class2 = 'resp-tabs-list';
    } else {
        $class1 = 'normal-tabs tabs-left-nav';
        $class2 = 'resp-tabs-list tabs clearfix text-center';
    }
    $out = '';
    $out .= '<div class="'.$class1.'">';
    $out .= '<ul class="'.$class2.'">';
    $ex_tab_headings = explode('+',$tab_headings);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        if($tabs_position == 'side'){
            $out .= '<li>' . $heading . '</li>';
        } else{
            $out .= '<li><a href="#." id="tab'. $heading_count .'">' . $heading . '</a></li>';
        }
        $heading_count++;
    }
    $out .= '</ul>';
    $out .= '<div class="resp-tabs-container">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('general_tabs', 'general_tabs_shortcode');
add_shortcode('general_tab', 'general_tab_shortcode');
function general_tab_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div>';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
// Toggles Shortcode
function toggles_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if(!empty($atts['class'])){
        $class = $atts['class'];
    } else {
        $class = '';
    }
    $out = '';
    if($style == 'bg'){
        $out .= '<div class="toggle toggle-bg '.$class.'">';
        $out .= '<div class="toggle-content">';
        $out .= '<p>'.$description.'</p>';
        $out .= '</div>';
        $out .= '<h3 class="toggle-heading">'.$heading.'</h3>';
        $out .= '</div>';
    } else {
        $out .= '<div class="toggle '.$class.'">';
        $out .= '<h3 class="toggle-heading">'.$heading.'</h3>';
        $out .= '<div class="toggle-content">';
        $out .= '<p>'.$description.'</p>';
        $out .= '</div>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('toggles', 'toggles_shortcode');
// Pricing Table Shortcode
function pricing_table_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['currency_symbol'])){
        $currency_symbol = $atts['currency_symbol'];
    } else {
        $currency_symbol = '';
    }
    if(!empty($atts['price'])){
        $price = $atts['price'];
    } else {
        $price = '';
    }
    if(!empty($atts['period_text'])){
        $period_text = $atts['period_text'];
    } else {
        $period_text = '';
    }
    if(!empty($atts['button_text'])){
        $button_text = $atts['button_text'];
    } else {
        $button_text = '';
    }
    if(!empty($atts['button_link'])){
        $button_link = $atts['button_link'];
    } else {
        $button_link = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
        if($style == 'active'){
            $class = 'highlight';
        } else {
            $class = '';
        }
    } else {
        $style = '';
        $class = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="pricing-table text-center '.$class.' animations-on '.$animations.'" data-delay="'.$delay.'">';
    $out .= '<h3 class="pricing-table-heading">'.$heading.'</h3>';
    $out .= '<p class="table-price"><span class="currency">'.$currency_symbol.'</span>'.$price.'<span>'.$period_text.'</span></p>';
    $out .= do_shortcode($content);
    $out .= '<br>';
    $out .= '<div class="pricing-table-footer">';
    if(!empty($button_text)){
        $out .= '<a href="'.$button_link.'" class="btn btn-default btn-medium">'.$button_text.'</a>';
    }
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pricing_table', 'pricing_table_shortcode');
// Pricing Tabs
function pricing_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tabs'])){
        $tabs = $atts['tabs'];
    } else {
        $tabs = '';
    }
    $out = '';
    $out .= '<div class="normal-tabs-bordered-btns">';
    $out .= '<ul class="resp-tabs-list tabs clearfix text-center">';
    $ex_tab_headings = explode('+',$tabs);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        $out .= '<li><a href="#." id="tab'. $heading_count .'">' . $heading . '</a></li>';
        $heading_count++;
    }
    $out .= '</ul>';
    $out .= '<div class="space80"></div>';
    $out .= '<div class="resp-tabs-container">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pricing_tabs', 'pricing_tabs_shortcode');
// Alerts
function alerts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = rawurldecode(base64_decode(strip_tags($atts['heading'])));
    } else {
        $heading = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = 'success';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="alert alert-'.$style.' animations-on '.$animations.'" role="alert" data-delay="'.$delay.'">';
    if($style == 'success'){
        $out .= '<i class="alert-left-icon icon-checkmark6"></i>';
    } elseif($style == 'warning'){
        $out .= '<i class="alert-left-icon icon-light-bulb2"></i>';
    } elseif($style == 'danger'){
        $out .= '<i class="alert-left-icon icon-warning6"></i>';
    } else{
        $out .= '<i class="alert-left-icon icon-question5"></i>';
    }
    $out .= $heading;
    $out .= '<i class="icon-close"></i>';
    $out .= '</div>';
    return $out;
}
add_shortcode('alerts', 'alerts_shortcode');
// List Items Shortcode
function list_items_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['style'])){
        $style = $atts['style'];
        if($style == 'ordered'){
            $class = 'list padding-left-20';
            $icon = '';
            $type = 'ol';
        } elseif($style == 'un-ordered'){
            $class = 'list padding-left-20';
            $icon = '';
            $type = 'ul';
        } elseif($style == 'defination'){
            $class = 'list solid padding-left-20 list-unstyled';
            $icon = '';
            $type = 'ul';
        } elseif($style == 'tick'){
            $class = 'list-icon padding-left-20 list-unstyled';
            $icon = 'ticko';
            $type = 'ul';
        } elseif($style == 'bulb'){
            $class = 'list-icon padding-left-20 list-unstyled';
            $icon = 'bulbo';
            $type = 'ul';
        } elseif($style == 'star'){
            $class = 'list-icon solid padding-left-20 list-unstyled';
            $icon = 'staro';
            $type = 'ul';
        } elseif($style == 'blue-circle'){
            $class = 'list-unstyled list-bullets';
            $icon = '';
            $type = 'ul';
        } else {
            $class = 'list padding-left-20';
            $icon = '';
            $type = 'ul';
        }
    } else {
        $style = '';
        $class = 'list padding-left-20';
        $icon = '';
        $type = 'ul';
    }
    $out = '';
    $out .= '<'.$type.' class="'.$icon.' '.$class.'">';
    $out .= do_shortcode($content);
    $out .= '</'.$type.'>';
    return $out;
}
add_shortcode('list_items', 'list_items_shortcode');
add_shortcode('list_item', 'list_item_shortcode');
function list_item_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['text'])){
        $text = rawurldecode(base64_decode(strip_tags($atts['text'])));
    } else {
        $text = '';
    }
    $out = '';
    $out .= '<li>';
    $out .= $text;
    $out .= '</li>';
    return $out;
}
// Text Widget Shortcode Readable
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');