<?php
/*
Plugin Name: Fajar CPT
Plugin URI: http://gomalthemes.com/
Description: Fajar custom post type's for only fajar wp theme.
Version: 1.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
// Creating Fajar Hero Slider CPT
function fajar_hero_slider() {
    register_post_type( 'fajar-hero-slider',
        array(
            'labels' => array(
                'name' => 'Hero Slider',
                'singular_name' => 'Slide',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Slide',
                'edit' => 'Edit',
                'edit_item' => 'Edit Slide',
                'new_item' => 'New Slide',
                'view' => 'View',
                'view_item' => 'View Slide',
                'search_items' => 'Search Slide',
                'not_found' => 'No Slide found',
                'not_found_in_trash' => 'No Slide found in Trash',
                'parent' => 'Parent Slide'
            ),

            'public' => true,
            'menu_position' => 30,
            'show_in_nav_menus' => false,
            'supports' => array( 'title'),
            'menu_icon' => plugins_url( 'img/slider.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_hero_slider' );
add_action( 'init', 'fajar_hero_taxonomies', 0 );
function fajar_hero_taxonomies() {
    register_taxonomy(
        'fajar_hero_genre',
        'fajar-hero-slider',
        array(
            'labels' => array(
                'name' => 'Slider Alias',
                'add_new_item' => 'Add New Alias',
                'new_item_name' => "New Alias"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Creating Fajar Tab Slider CPT
function fajar_tab_slider() {
    register_post_type( 'fajar-tab-slider',
        array(
            'labels' => array(
                'name' => 'Tabs Slider',
                'singular_name' => 'Slide',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Slide',
                'edit' => 'Edit',
                'edit_item' => 'Edit Slide',
                'new_item' => 'New Slide',
                'view' => 'View',
                'view_item' => 'View Slide',
                'search_items' => 'Search Slide',
                'not_found' => 'No Slide found',
                'not_found_in_trash' => 'No Slide found in Trash',
                'parent' => 'Parent Slide'
            ),

            'public' => true,
            'menu_position' => 31,
            'show_in_nav_menus' => false,
            'supports' => array( 'title'),
            'menu_icon' => plugins_url( 'img/tabs-slider.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_tab_slider' );
add_action( 'init', 'fajar_tab_taxonomies', 0 );
function fajar_tab_taxonomies() {
    register_taxonomy(
        'fajar_tab_genre',
        'fajar-tab-slider',
        array(
            'labels' => array(
                'name' => 'Slider Alias',
                'add_new_item' => 'Add New Alias',
                'new_item_name' => "New Alias"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Creating Fajar Portfolio CPT
function fajar_portfolio() {
    register_post_type( 'portfolio',
        array(
            'labels' => array(
                'name' => 'Portfolio',
                'singular_name' => 'Portfolio',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Portfolio',
                'edit' => 'Edit',
                'edit_item' => 'Edit Portfolio',
                'new_item' => 'New Portfolio',
                'view' => 'View',
                'view_item' => 'View Portfolio',
                'search_items' => 'Search Portfolio',
                'not_found' => 'No Portfolio found',
                'not_found_in_trash' => 'No Portfolio found in Trash',
                'parent' => 'Parent Portfolio'
            ),

            'public' => true,
            'menu_position' => 21,
            'show_in_nav_menus' => false,
            'supports' => array( 'title','editor','thumbnail'),
            'menu_icon' => plugins_url( 'img/portfolio.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_portfolio' );
add_action( 'init', 'fajar_taxonomies', 0 );
function fajar_taxonomies() {
    register_taxonomy(
        'fajar_genre',
        'portfolio',
        array(
            'labels' => array(
                'name' => 'Portfolio Categories',
                'add_new_item' => 'Add New Portfolio Category',
                'new_item_name' => "New Portfolio Category"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Setting Custom Column For Portfolio
add_filter( 'manage_edit-portfolio_columns', 'my_edit_portfolio_columns' ) ;
function my_edit_portfolio_columns( $columns ) {
    $columns = array(
        'cb' => '<input type="checkbox" />',
        'title' => __( 'Portfolio Title' ),
        'portfolio_single_item_layout' => __( 'Single Page Layout' ),
        'fajar_genre' => __( 'Categories' )
    );
    return $columns;
}
add_action( 'manage_portfolio_posts_custom_column', 'my_manage_portfolio_columns', 10, 2 );
function my_manage_portfolio_columns( $column, $post_id ) {
    global $post;
    switch( $column ) {
        case 'portfolio_single_item_layout' :
            $single_page_layout_meta = get_post_meta( $post_id, 'portfolio_single_item_layout', true );
            $single_page_layout = get_field_object( 'portfolio_single_item_layout', $post_id );;
            if ( empty( $single_page_layout['choices'][$single_page_layout_meta] ) )
                echo __( 'Unknown' );
            else
                printf( __( '%s' ), $single_page_layout['choices'][$single_page_layout_meta] );
            break;
        case 'fajar_genre' :
            $terms = get_the_terms( $post_id, 'fajar_genre' );
            if ( !empty( $terms ) ) {
                $out = array();
                foreach ( $terms as $term ) {
                    $out[] = sprintf( '<a href="%s">%s</a>',
                        esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'fajar_genre' => $term->slug ), 'edit.php' ) ),
                        esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'fajar_genre', 'display' ) )
                    );
                }
                echo join( ', ', $out );
            }
            else {
                _e( 'No Categories.' );
            }
            break;
        default :
            break;
    }
}
// Creating FAQ CPT
function fajar_faq() {
    register_post_type( 'fajar-faq',
        array(
            'labels' => array(
                'name' => 'FAQ',
                'singular_name' => 'FAQ',
                'add_new' => 'Add FAQ',
                'add_new_item' => 'Add New FAQ',
                'edit' => 'Edit',
                'edit_item' => 'Edit FAQ',
                'new_item' => 'New FAQ',
                'view' => 'View',
                'view_item' => 'View FAQ',
                'search_items' => 'Search FAQ',
                'not_found' => 'No FAQ found',
                'not_found_in_trash' => 'No FAQ found in Trash',
                'parent' => 'Parent FAQ'
            ),

            'public' => true,
            'supports' => array( 'title','editor'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/team.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_faq' );
add_action( 'init', 'fajar_faq_taxonomies', 0 );
function fajar_faq_taxonomies() {
    register_taxonomy(
        'fajar_faq_genre',
        'fajar-faq',
        array(
            'labels' => array(
                'name' => 'Groups',
                'add_new_item' => 'Add New Group',
                'new_item_name' => "New Group"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Creating Testimonial CPT
function fajar_testimonials() {
    register_post_type( 'fajar-testimonials',
        array(
            'labels' => array(
                'name' => 'Testimonials',
                'singular_name' => 'Testimonial',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Testimonial',
                'edit' => 'Edit',
                'edit_item' => 'Edit Testimonial',
                'new_item' => 'New Testimonial',
                'view' => 'View',
                'view_item' => 'View Testimonial',
                'search_items' => 'Search Testimonial',
                'not_found' => 'No Testimonial found',
                'not_found_in_trash' => 'No Testimonial found in Trash',
                'parent' => 'Parent Testimonial'
            ),

            'public' => true,
            'supports' => array( 'title','editor','thumbnail'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/testimonials.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_testimonials' );
add_action( 'init', 'fajar_test_taxonomies', 0 );
function fajar_test_taxonomies() {
    register_taxonomy(
        'fajar_testimonials_genre',
        'fajar-testimonials',
        array(
            'labels' => array(
                'name' => 'Groups',
                'add_new_item' => 'Add New Group',
                'new_item_name' => "New Group"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Creating Services
function fajar_services() {
    register_post_type( 'fajar-services',
        array(
            'labels' => array(
                'name' => 'Creative Services',
                'singular_name' => 'Service',
                'add_new' => 'Add New Service',
                'add_new_item' => 'Add New Service',
                'edit' => 'Edit',
                'edit_item' => 'Edit Service',
                'new_item' => 'New Service',
                'view' => 'View',
                'view_item' => 'View Service',
                'search_items' => 'Search Service',
                'not_found' => 'No Service found',
                'not_found_in_trash' => 'No Service found in Trash',
                'parent' => 'Parent Service'
            ),

            'public' => true,
            'supports' => array( 'title','editor','thumbnail'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/sections.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_services' );
// Creating Store Locator CPT
function fajar_store_locator_cpt() {
    register_post_type( 'fajar-store-locator',
        array(
            'labels' => array(
                'name' => 'Store Locators',
                'singular_name' => 'Store Locator',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Store Locator',
                'edit' => 'Edit',
                'edit_item' => 'Edit Store Locator',
                'new_item' => 'New Store Locator',
                'view' => 'View',
                'view_item' => 'View Store Locator',
                'search_items' => 'Search Store Locator',
                'not_found' => 'No Store Locator found',
                'not_found_in_trash' => 'No Store Locator found in Trash',
                'parent' => 'Parent Store Locator'
            ),

            'public' => true,
            'supports' => array( 'title'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/store.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'fajar_store_locator_cpt' );
add_action( 'init', 'fajar_store_locator_taxonomies', 0 );
function fajar_store_locator_taxonomies() {
    register_taxonomy(
        'fajar_store_locator_genre',
        'fajar-store-locator',
        array(
            'labels' => array(
                'name' => 'Tags',
                'add_new_item' => 'Add New Tag',
                'new_item_name' => "New Tag"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}